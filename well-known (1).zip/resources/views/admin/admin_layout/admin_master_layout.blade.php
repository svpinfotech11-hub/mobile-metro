@include('admin.admin_layout.admin_header')
@include('admin.admin_layout.admin_sidebar')

<div class="content-wrapper">
    @yield('content')
</div>

@include('admin.admin_layout.admin_footer')
