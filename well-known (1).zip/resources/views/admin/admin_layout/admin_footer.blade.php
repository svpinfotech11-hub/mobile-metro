  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2024-2025 <a href="https://www.svpinfotech.com/">SVP Infotech</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="{{ asset('') }}admin_assets/plugins/jquery/jquery.min.js"></script>

<!-- Bootstrap -->
<script src="{{ asset('') }}admin_assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="{{ asset('') }}admin_assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="{{ asset('') }}admin_assets/dist/js/adminlte.js"></script>

<!-- PAGE {{ asset('') }}admin_assets/plugins -->
<!-- jQuery Mapael -->
<script src="{{ asset('') }}admin_assets/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="{{ asset('') }}admin_assets/plugins/raphael/raphael.min.js"></script>
<script src="{{ asset('') }}admin_assets/plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="{{ asset('') }}admin_assets/plugins/jquery-mapael/maps/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="{{ asset('') }}admin_assets/plugins/chart.js/Chart.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="{{ asset('') }}admin_assets/dist/js/demo.js"></script>

<script src="{{ asset('') }}admin_assets/dist/js/pages/dashboard3.js"></script>
</body>
</html>
